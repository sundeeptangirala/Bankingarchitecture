# Banking Business Architecture Intake v6 — Clickable Module Dossier

This version simplifies the UX.

## Why v6 exists
The v5 form was too long because it rendered every module's full business and architecture form at once.

v6 changes the interaction model:
- Show one dependency map.
- Keep all modules visible.
- Highlight default modules.
- Let users click one module at a time.
- Show a compact right-side module dossier.
- Let users add extra modules by clicking faded modules.
- Business and architecture use the same view with different modes.

## Flow

1. Select a starting point:
   - Small Business Banking
   - TM Payments
   - ABL
   - ACH
   - Wires
   - Commercial Onboarding
   - etc.

2. Enter short request context.

3. Dependency map lights up default modules.

4. Business mode:
   - Click a module.
   - Enter need, current state, pain, priority, questions.

5. Architecture mode:
   - Click the same module.
   - Review default assumptions.
   - Set availability:
     - Available and reusable
     - Available but coupled to existing module/platform
     - Available but needs extension
     - Not available / gap
     - Vendor/product needed
     - Integration layer needed
     - Not applicable
   - Set disposition/action:
     - Reuse existing
     - Extend existing
     - Deep dive assessment
     - RFP/vendor evaluation
     - Add to integration layer
     - Create roadmap item
   - Enter owner, risks, integrations, decision, notes.

6. Export JSON or CSV.

## Key design idea
Do not show a never-ending form. Show a map and a module dossier.
