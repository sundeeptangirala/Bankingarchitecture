# Business Architecture Intake v8 — FNB Product Coverage

This version keeps the simple clickable module-dossier UX and expands the content model for broader FNB product/service coverage.

## New / renamed platform modules

### Added
- Deposit & Account Servicing
- Cards & Card Servicing
- Capital Markets / Advisory

### Existing renamed
- Treasury & Payments → Treasury, Payments & Liquidity
- Collateral / ABL → Collateral, Asset Monitoring & ABL

### Previously added and retained
- Collections / Recovery

## New selectable starting points

### LOB / Segment views
- Consumer / Retail Banking
- Wealth Management
- Private Banking
- Government / Public Finance

### Deposit / Account views
- Personal Checking & Savings
- Business Checking & Savings
- Nonprofit / IOLTA / Specialty Deposits

### Digital / TM views
- Business Online Banking
- Remote Deposit / Desktop Banker
- Positive Pay / Fraud Protection
- Controlled Disbursement

### Cards
- Purchasing Card
- Business Credit Cards
- Personal Credit Cards
- Debit Card / Card Management

### Lending
- Home Equity
- Vehicle Loans
- SBA Lending
- Commercial Real Estate Lending
- Consumer Lending
- Mortgage
- Mortgage Servicing
- Collections / Recovery

### Capital Markets / Advisory
- Loan Syndications
- International Banking / FX
- Trade Finance
- Interest Rate Swaps / Hedging
- Investment Banking / M&A Advisory

### Wealth / Insurance
- Retirement Plan Services
- Insurance

## Design principles

1. Keep the module map simple.
2. Add FNB product/service coverage as selectable starting points.
3. Use the clickable module dossier instead of long never-ending forms.
4. Let business users add extra modules when defaults miss something.
5. Let architecture review defaults and classify availability/action:
   - Available and reusable
   - Available but coupled to existing module/platform
   - Available but needs extension
   - Not available / gap
   - Vendor/product needed
   - Integration layer needed

## Why this version is better

v8 is closer to a practical bank-wide business architecture intake tool. It supports discussions across retail, small business, commercial, treasury, lending, mortgage, collections, wealth, insurance, and capital markets without turning the module canvas into an unreadable enterprise architecture diagram.
