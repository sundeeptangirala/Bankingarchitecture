# Banking Business Architecture Intake — Streamlit v4 Compact Clickable Tiles

This version fixes the UX issue where each module tile had a separate **Open** button.

## UX changes

- The tile itself is clickable.
- Faded tiles can be clicked directly to add them to scope.
- No separate Open button under every module.
- More compact spacing.
- Five-column module grid on wider screens.
- Shorter card descriptions.
- Document prefill moved into a collapsed expander.
- Same right-side compact module dossier.
- Same SQLite request storage and architecture review queue.

## Functionality retained

- FNB v8 product/module coverage
- Request creation and save/submit
- Architecture review queue
- Business input mode
- Architecture review mode
- Summary mode
- Document extraction / prefill
- JSON and CSV exports

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Storage

Local prototype storage:

```text
architecture_requests.db
```

For enterprise, replace SQLite with SQL Server, Snowflake, Postgres, Dataverse, SharePoint Lists, or an internal API-backed service.
