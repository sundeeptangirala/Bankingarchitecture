
import json
import sqlite3
import uuid
import io
import re
import html
from urllib.parse import quote
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Set, Tuple

import pandas as pd
import streamlit as st

APP_DIR = Path(__file__).parent
DATA_FILE = APP_DIR / "architecture_data.json"
DB_FILE = APP_DIR / "architecture_requests.db"
LAYER_ORDER = ["Experience / Engagement", "Business Core", "Enterprise Shared"]

STATUS_OPTIONS = ["Draft", "Submitted", "In Architecture Review", "Needs Business Follow-up", "Decision Required", "Approved", "Closed"]
REQUEST_TYPES = ["New product / service", "Enhancement to existing capability", "Vendor / RFP evaluation", "Process improvement", "Risk / compliance need", "Data / AI use case", "Other"]

def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

@st.cache_data
def load_data() -> Dict[str, Any]:
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))

def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS requests (
          request_id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          sponsor TEXT,
          selected_starting_point TEXT NOT NULL,
          selected_type TEXT,
          status TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          payload_json TEXT NOT NULL
        )
        """)
        conn.commit()

def save_payload(payload: Dict[str, Any]) -> str:
    init_db()
    rid = payload.get("request_id") or str(uuid.uuid4())
    payload["request_id"] = rid
    payload.setdefault("created_at", now_iso())
    payload["updated_at"] = now_iso()
    ctx = payload.get("request_context", {})
    title = ctx.get("name") or f"{payload.get('selected_starting_point', 'Request')} - {rid[:8]}"
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
        INSERT INTO requests(request_id,title,sponsor,selected_starting_point,selected_type,status,created_at,updated_at,payload_json)
        VALUES(?,?,?,?,?,?,?,?,?)
        ON CONFLICT(request_id) DO UPDATE SET
          title=excluded.title, sponsor=excluded.sponsor, selected_starting_point=excluded.selected_starting_point,
          selected_type=excluded.selected_type, status=excluded.status, updated_at=excluded.updated_at,
          payload_json=excluded.payload_json
        """, (
            rid, title, ctx.get("sponsor",""), payload.get("selected_starting_point",""), payload.get("selected_type",""),
            payload.get("status","Draft"), payload.get("created_at", now_iso()), payload["updated_at"], json.dumps(payload)
        ))
        conn.commit()
    return rid

def list_requests(status="All") -> pd.DataFrame:
    init_db()
    q = "SELECT request_id,title,sponsor,selected_starting_point,selected_type,status,created_at,updated_at FROM requests"
    params = ()
    if status != "All":
        q += " WHERE status=?"
        params = (status,)
    q += " ORDER BY updated_at DESC"
    with sqlite3.connect(DB_FILE) as conn:
        return pd.read_sql_query(q, conn, params=params)

def load_request(rid: str) -> Dict[str, Any]:
    init_db()
    with sqlite3.connect(DB_FILE) as conn:
        row = conn.execute("SELECT payload_json FROM requests WHERE request_id=?", (rid,)).fetchone()
    if not row:
        raise ValueError("Request not found")
    return json.loads(row[0])

def delete_request(rid: str):
    init_db()
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("DELETE FROM requests WHERE request_id=?", (rid,))
        conn.commit()

def item(data, selected):
    return data["items"][selected]

def module_by_id(data, mid):
    return next(m for m in data["modules"] if m["id"] == mid)

def default_relevant(data, selected) -> List[Dict[str, str]]:
    it = item(data, selected)
    return ([{"id": x, "state": "primary"} for x in it.get("primary", [])] +
            [{"id": x, "state": "supporting"} for x in it.get("supporting", [])] +
            [{"id": x, "state": "optional"} for x in it.get("optional", [])])

def default_ids(data, selected) -> Set[str]:
    return {x["id"] for x in default_relevant(data, selected)}

def in_scope_ids(data, payload) -> Set[str]:
    return default_ids(data, payload["selected_starting_point"]) | set(payload.get("added_modules", []))

def dep_state(data, payload, mid) -> str:
    selected = payload["selected_starting_point"]
    it = item(data, selected)
    if mid in it.get("primary", []): return "primary"
    if mid in it.get("supporting", []): return "supporting"
    if mid in it.get("optional", []): return "optional"
    if mid in payload.get("added_modules", []): return "added"
    return "dimmed"

def defaults_for(data, payload, mid):
    return data.get("architecture_defaults", {}).get(payload["selected_starting_point"], {}).get(mid, {
        "default_disposition": "Unknown",
        "likely_owners": "",
        "likely_risks": "",
        "likely_integrations": "",
        "review_question": "What should the architecture team decide for this module?"
    })

def helper_for(data, mid):
    return data.get("module_helpers", {}).get(mid, "Enter what this request needs from this module.")

def blank_payload(data, selected="Small Business Banking"):
    if selected not in data["items"]:
        selected = list(data["items"].keys())[0]
    payload = {
        "request_id": "",
        "status": "Draft",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "selected_starting_point": selected,
        "selected_type": item(data, selected)["type"],
        "request_context": {
            "name": "",
            "sponsor": "",
            "request_type": "New product / service",
            "target_users": "",
            "problem": ""
        },
        "added_modules": [],
        "business_input": {},
        "architecture_review": {}
    }
    return ensure_records(data, payload)

def ensure_records(data, payload):
    payload.setdefault("added_modules", [])
    payload.setdefault("business_input", {})
    payload.setdefault("architecture_review", {})
    for mid in in_scope_ids(data, payload):
        payload["business_input"].setdefault(mid, {
            "need": "", "today": "", "pain": "", "priority": "Must-have", "questions": ""
        })
        d = defaults_for(data, payload, mid)
        payload["architecture_review"].setdefault(mid, {
            "status": "Not reviewed",
            "availability": "Unknown",
            "disposition": d.get("default_disposition", "Unknown"),
            "action": "Validate default with SMEs",
            "owner": d.get("likely_owners", ""),
            "risks": d.get("likely_risks", ""),
            "integrations": d.get("likely_integrations", ""),
            "decision": d.get("review_question", ""),
            "notes": ""
        })
    return payload

def apply_default(data, payload, mid):
    d = defaults_for(data, payload, mid)
    old_notes = payload.get("architecture_review", {}).get(mid, {}).get("notes", "")
    payload["architecture_review"][mid] = {
        "status": "Default accepted",
        "availability": "Unknown",
        "disposition": d.get("default_disposition", "Unknown"),
        "action": "Validate default with SMEs",
        "owner": d.get("likely_owners", ""),
        "risks": d.get("likely_risks", ""),
        "integrations": d.get("likely_integrations", ""),
        "decision": d.get("review_question", ""),
        "notes": old_notes
    }

def business_done(payload, mid):
    b = payload.get("business_input", {}).get(mid, {})
    return any(str(b.get(k, "")).strip() for k in ["need","today","pain","questions"])

def arch_done(payload, mid):
    a = payload.get("architecture_review", {}).get(mid, {})
    return bool(a.get("status") and a.get("status") != "Not reviewed")

def counts(data, payload):
    ids = in_scope_ids(data, payload)
    return {
        "default": len(default_ids(data, payload["selected_starting_point"])),
        "added": len(payload.get("added_modules", [])),
        "business": sum(1 for mid in ids if business_done(payload, mid)),
        "architecture": sum(1 for mid in ids if arch_done(payload, mid)),
        "scope": len(ids)
    }

def export_rows(data, payload):
    rows = []
    for mid in sorted(in_scope_ids(data, payload)):
        m = module_by_id(data, mid)
        d = defaults_for(data, payload, mid)
        b = payload.get("business_input", {}).get(mid, {})
        a = payload.get("architecture_review", {}).get(mid, {})
        rows.append({
            "request_id": payload.get("request_id",""),
            "starting_point": payload["selected_starting_point"],
            "module": m["name"],
            "dependency_type": dep_state(data, payload, mid),
            "business_need": b.get("need",""),
            "today": b.get("today",""),
            "pain": b.get("pain",""),
            "priority": b.get("priority",""),
            "business_questions": b.get("questions",""),
            "default_disposition": d.get("default_disposition",""),
            "availability": a.get("availability",""),
            "disposition": a.get("disposition",""),
            "action": a.get("action",""),
            "owner": a.get("owner",""),
            "risks": a.get("risks",""),
            "integrations": a.get("integrations",""),
            "decision": a.get("decision",""),
            "notes": a.get("notes","")
        })
    return rows

def css():
    st.markdown("""
<style>
:root{
  --bg:#f5f7fb; --panel:#fff; --ink:#172033; --muted:#667085; --line:#d9e0eb;
  --primary:#123c69; --primary2:#1d5f99; --support:#4f82b8; --optional:#8fb3d3; --dim:#e7ebf2;
  --green:#2f855a; --amber:#b7791f; --red:#b83232; --purple:#6b46c1;
  --shadow:0 12px 30px rgba(18,60,105,.11);
}
.stApp {
  background:linear-gradient(180deg,#eef3fb 0%,#f7f9fc 40%,#f5f7fb 100%);
  color:var(--ink);
}
.block-container {padding-top: .65rem; padding-bottom: 1.5rem; max-width: 1560px;}
[data-testid="stSidebar"] {background:#ffffff;}
.app-header{
  background:rgba(255,255,255,.93); backdrop-filter:blur(10px);
  border:1px solid var(--line); border-radius:18px; padding:12px 18px; margin-bottom:12px;
  box-shadow:var(--shadow);
}
.app-title{font-size:22px;letter-spacing:-.03em;margin:0;font-weight:950;color:var(--ink);}
.subtitle{color:var(--muted);font-size:13px;line-height:1.35;margin-top:4px;max-width:1180px}
.banner{
  display:grid; grid-template-columns:1fr auto; gap:10px; align-items:center;
  background:#f8fbff; border:1px solid #d4e3f4; border-radius:16px; padding:10px 13px; margin-bottom:10px;
}
.banner-title{font-size:18px;font-weight:950}
.banner-text{color:var(--muted);font-size:12.5px;margin-top:3px;line-height:1.32}
.type-tag{border-radius:999px;padding:7px 10px;background:#eef6ff;color:var(--primary);font-size:12px;font-weight:850;border:1px solid #cbdff3;white-space:nowrap}
.panel{
  background:rgba(255,255,255,.95); border:1px solid var(--line); border-radius:18px; 
  box-shadow:var(--shadow); padding:12px; margin-bottom:12px;
}
.section-title{font-size:16px;font-weight:900;margin:0 0 6px;color:var(--ink)}
.small-muted{font-size:12px;color:var(--muted);line-height:1.32}
.legend-pill {
  display:inline-flex; gap:6px; align-items:center; font-size:12px; color:var(--muted); 
  background:#fff; border:1px solid var(--line); border-radius:999px; padding:6px 9px; margin:2px 4px 10px 0;
}
.dot{width:10px;height:10px;border-radius:50%;display:inline-block}
.metric-card{background:#f8fafc;border:1px solid #edf1f6;border-radius:13px;padding:8px 10px;margin-bottom:6px}
.metric-number{font-size:20px;font-weight:950;color:var(--primary);line-height:1}
.metric-label{font-size:11px;color:var(--muted);font-weight:850;line-height:1.2;margin-top:4px}
.layer-title{font-size:12px;text-transform:uppercase;letter-spacing:.08em;font-weight:950;color:#4a5568;margin:12px 0 6px}
.module-card{min-height:108px;border:1px solid var(--line);border-radius:17px;padding:12px;background:#fff;transition:.16s ease;position:relative;overflow:hidden;box-shadow:0 6px 14px rgba(18,60,105,.06);margin-bottom:6px}
.module-name{font-weight:950;font-size:13px;line-height:1.18;margin-bottom:6px}
.module-desc{font-size:11.5px;line-height:1.3;color:var(--muted);padding-right:16px}
.badge{display:inline-block;margin-top:8px;font-size:9px;font-weight:950;text-transform:uppercase;border-radius:999px;padding:4px 7px}
.status-dot{position:absolute;right:9px;top:9px;width:9px;height:9px;border-radius:50%;background:#cbd5e1}
.default-box,.helper-box,.callout{border-radius:14px;padding:11px;font-size:13px;line-height:1.45;margin:10px 0}
.default-box{background:#fffaf0;border:1px solid #f1d7a8;color:#5a3b0a}
.helper-box{background:#f8fafc;border:1px solid #edf1f6;color:#475467}
.callout{background:#eefaf4;border:1px solid #b8e2ca;color:#174a31}
.stButton>button {
  border-radius:12px !important; font-weight:850 !important; border:1px solid var(--line) !important;
}
.stButton>button[kind="primary"] {
  background:var(--primary) !important; color:white !important;
}
div[data-testid="stVerticalBlockBorderWrapper"]{border-radius:22px !important}

.module-grid{
  display:grid;
  grid-template-columns:repeat(5,minmax(126px,1fr));
  gap:8px;
  margin-bottom:8px;
}
a.module-tile{
  display:block;
  min-height:88px;
  border:1px solid var(--line);
  border-radius:15px;
  padding:9px 10px;
  text-decoration:none !important;
  color:var(--ink) !important;
  box-shadow:0 5px 12px rgba(18,60,105,.055);
  transition:all .13s ease;
  position:relative;
  overflow:hidden;
}
a.module-tile:hover{
  transform:translateY(-1px);
  box-shadow:0 10px 18px rgba(18,60,105,.13);
  border-color:#f6ad55 !important;
}
a.module-tile.primary{
  background:linear-gradient(135deg,#123c69,#1d5f99);
  color:#fff !important;
  border-color:#123c69;
}
a.module-tile.supporting{background:#eef6ff;border-color:#9cc0e4}
a.module-tile.optional{background:#f7fbff;border-color:#b8d2e8}
a.module-tile.added{background:#f3edff;border-color:#c4b5fd}
a.module-tile.dimmed{background:#f3f5f8;opacity:.42;filter:grayscale(.4)}
a.module-tile.selected{
  outline:3px solid #f6ad55;
  outline-offset:1px;
}
.tile-name{
  font-weight:950;
  font-size:12.2px;
  line-height:1.13;
  margin-bottom:4px;
  padding-right:13px;
}
.tile-desc{
  font-size:10.5px;
  line-height:1.22;
  color:#667085;
}
a.module-tile.primary .tile-desc{color:rgba(255,255,255,.82)}
.tile-badge{
  display:inline-block;
  margin-top:6px;
  font-size:8.5px;
  font-weight:950;
  text-transform:uppercase;
  border-radius:999px;
  padding:3px 6px;
  background:#ffffffaa;
}
a.module-tile.primary .tile-badge{background:rgba(255,255,255,.18);color:#fff}
.tile-status-dot{
  position:absolute;
  right:8px;
  top:8px;
  width:8px;
  height:8px;
  border-radius:50%;
  background:#cbd5e1;
}
.compact-note{font-size:11.5px;color:#667085;line-height:1.25;margin-bottom:6px}
div[data-testid="stVerticalBlock"]{gap:.45rem;}
div[data-testid="stHorizontalBlock"]{gap:.65rem;}
@media(max-width:1200px){.module-grid{grid-template-columns:repeat(4,minmax(126px,1fr));}}
@media(max-width:850px){.module-grid{grid-template-columns:repeat(2,minmax(126px,1fr));}}
</style>
""", unsafe_allow_html=True)

def card_html(name, desc, state, selected=False, bdone=False, adone=False):
    bg = {
        "primary": "linear-gradient(135deg,#123c69,#1d5f99)",
        "supporting": "#eef6ff",
        "optional": "#f7fbff",
        "added": "#f3edff",
        "dimmed": "#f3f5f8",
    }.get(state, "#fff")
    text = "#fff" if state == "primary" else "#172033"
    desc_color = "rgba(255,255,255,.82)" if state == "primary" else "#667085"
    border = "3px solid #f6ad55" if selected else "1px solid #d9e0eb"
    opacity = ".30" if state == "dimmed" else "1"
    badge_bg = "rgba(255,255,255,.18)" if state == "primary" else "#ffffffaa"
    badge_text = "#fff" if state == "primary" else "#172033"
    dot_color = "#cbd5e1"
    if bdone and adone: dot_color = "#6b46c1"
    elif bdone: dot_color = "#b7791f"
    elif adone: dot_color = "#2f855a"
    label = {"primary":"primary","supporting":"supporting","optional":"optional","added":"added","dimmed":"click add"}[state]
    return f"""
<div class="module-card" style="background:{bg};color:{text};border:{border};opacity:{opacity};">
  <span class="status-dot" style="background:{dot_color}"></span>
  <div class="module-name">{name}</div>
  <div class="module-desc" style="color:{desc_color};">{desc}</div>
  <span class="badge" style="background:{badge_bg};color:{badge_text};">{label}</span>
</div>
"""

def render_metrics(data, payload):
    c = counts(data, payload)
    cols = st.columns(4)
    vals = [("Default modules", c["default"]), ("Added modules", c["added"]), ("Business-filled", c["business"]), ("Architecture-reviewed", c["architecture"])]
    for col, (label, value) in zip(cols, vals):
        with col:
            st.markdown(f'<div class="metric-card"><div class="metric-number">{value}</div><div class="metric-label">{label}</div></div>', unsafe_allow_html=True)

def process_tile_query_params(data, payload):
    """Process clickable tile query params and update selected module / added scope."""
    try:
        params = st.query_params
        selected_mid = params.get("selected_module", None)
        add_mid = params.get("add_module", None)
    except Exception:
        selected_mid = None
        add_mid = None

    valid_ids = {m["id"] for m in data["modules"]}
    changed = False

    if add_mid and add_mid in valid_ids and add_mid not in payload.get("added_modules", []):
        payload.setdefault("added_modules", []).append(add_mid)
        ensure_records(data, payload)
        changed = True

    if selected_mid and selected_mid in valid_ids:
        st.session_state.selected_module = selected_mid

    return changed


def tile_href(mid: str, state: str) -> str:
    q_mid = quote(mid)
    if state == "dimmed":
        return f"?selected_module={q_mid}&add_module={q_mid}"
    return f"?selected_module={q_mid}"


def render_map(data, payload):
    st.markdown("""
<span class="legend-pill"><span class="dot" style="background:#123c69"></span>Primary</span>
<span class="legend-pill"><span class="dot" style="background:#4f82b8"></span>Supporting</span>
<span class="legend-pill"><span class="dot" style="background:#8fb3d3"></span>Optional</span>
<span class="legend-pill"><span class="dot" style="background:#6b46c1"></span>User-added</span>
<span class="legend-pill"><span class="dot" style="background:#e7ebf2"></span>Click tile to add</span>
""", unsafe_allow_html=True)
    selected_mid = st.session_state.get("selected_module")
    for layer in LAYER_ORDER:
        mods = [m for m in data["modules"] if m.get("layer") == layer]
        tiles = []
        for m in mods:
            mid = m["id"]
            state = dep_state(data, payload, mid)
            desc = m.get("description", "")
            desc = desc[:76] + ("..." if len(desc) > 76 else "")
            selected_class = " selected" if selected_mid == mid else ""
            bdone = business_done(payload, mid)
            adone = arch_done(payload, mid)
            dot = "#cbd5e1"
            if bdone and adone:
                dot = "#6b46c1"
            elif bdone:
                dot = "#b7791f"
            elif adone:
                dot = "#2f855a"
            label = {"primary":"primary","supporting":"supporting","optional":"optional","added":"added","dimmed":"click add"}.get(state, state)
            tiles.append(f"""
<a class="module-tile {state}{selected_class}" href="{tile_href(mid, state)}" title="Click to open {html.escape(m['name'])}">
  <span class="tile-status-dot" style="background:{dot}"></span>
  <div class="tile-name">{html.escape(m["name"])}</div>
  <div class="tile-desc">{html.escape(desc)}</div>
  <span class="tile-badge">{label}</span>
</a>
""")
        st.markdown(f'<div class="layer-title">{html.escape(layer)}</div><div class="module-grid">{"".join(tiles)}</div>', unsafe_allow_html=True)

def request_context(payload):
    st.markdown('<div class="section-title">1. Request context</div>', unsafe_allow_html=True)
    st.markdown('<div class="small-muted">Keep this short. Module details go into the clicked dossier.</div>', unsafe_allow_html=True)
    ctx = payload["request_context"]
    c1,c2 = st.columns(2)
    with c1:
        ctx["name"] = st.text_input("Request / idea name", ctx.get("name",""), placeholder="e.g., Small business payment package")
        ctx["request_type"] = st.selectbox("Request type", REQUEST_TYPES, index=REQUEST_TYPES.index(ctx.get("request_type", "New product / service")) if ctx.get("request_type") in REQUEST_TYPES else 0)
    with c2:
        ctx["sponsor"] = st.text_input("LOB / sponsor", ctx.get("sponsor",""), placeholder="e.g., Small Business Banking")
        ctx["target_users"] = st.text_input("Target users", ctx.get("target_users",""), placeholder="e.g., clients, bankers, ops, contact center")
    ctx["problem"] = st.text_area("Business problem / outcome", ctx.get("problem",""), placeholder="What problem are we solving and what outcome do we need?", height=92)

def render_dossier(data, payload, role_mode):
    mid = st.session_state.get("selected_module")
    if not mid or mid not in {m["id"] for m in data["modules"]}:
        mid = next(iter(in_scope_ids(data, payload)), None)
        st.session_state.selected_module = mid
    if not mid:
        st.info("Click a module to begin.")
        return
    ensure_records(data, payload)
    m = module_by_id(data, mid)
    state = dep_state(data, payload, mid)
    d = defaults_for(data, payload, mid)
    st.markdown(f'<div class="section-title">Module dossier: {m["name"]}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="small-muted">{state.title()} dependency · {m.get("description","")}</div>', unsafe_allow_html=True)
    if mid in payload.get("added_modules", []):
        if st.button("Remove added module", key=f"remove_{mid}"):
            payload["added_modules"] = [x for x in payload.get("added_modules", []) if x != mid]
            st.session_state.selected_module = next(iter(in_scope_ids(data, payload)), None)
            st.rerun()

    if role_mode == "Business input":
        st.markdown(f'<div class="helper-box"><b>What to enter:</b> {helper_for(data, mid)}</div>', unsafe_allow_html=True)
        b = payload["business_input"][mid]
        b["need"] = st.text_area("What does this request need from this module?", b.get("need",""), height=95)
        b["today"] = st.text_area("What exists / happens today?", b.get("today",""), height=75)
        b["pain"] = st.text_area("What is painful, missing, risky, or manual?", b.get("pain",""), height=75)
        c1,c2 = st.columns(2)
        with c1:
            priorities = ["Must-have", "Should-have", "Nice-to-have", "Future phase", "Unknown", "Not applicable"]
            b["priority"] = st.selectbox("Priority", priorities, index=priorities.index(b.get("priority", "Must-have")) if b.get("priority") in priorities else 0)
        with c2:
            b["questions"] = st.text_input("Open questions", b.get("questions",""))
        st.markdown('<div class="callout"><b>Next:</b> Architecture reviews defaults and decides reuse, extension, gap, vendor/product need, integration layer, or deep dive.</div>', unsafe_allow_html=True)

    elif role_mode == "Architecture review":
        st.markdown(f"""
<div class="default-box">
<b>Default architecture starting point</b><br>
<b>Disposition:</b> {d.get("default_disposition","Unknown")}<br>
<b>Likely owners:</b> {d.get("likely_owners","Unknown")}<br>
<b>Likely risks:</b> {d.get("likely_risks","Unknown")}<br>
<b>Likely integrations:</b> {d.get("likely_integrations","Unknown")}<br>
<b>Review question:</b> {d.get("review_question","Unknown")}
</div>
""", unsafe_allow_html=True)
        if st.button("Apply default", key=f"apply_{mid}"):
            apply_default(data, payload, mid)
            st.rerun()
        a = payload["architecture_review"][mid]
        status_ops = ["Not reviewed","Default accepted","Default modified","Needs SME review","Deep dive assessment needed","Decision required"]
        avail_ops = ["Unknown","Available and reusable","Available but coupled to existing module/platform","Available but needs extension","Not available / gap","Vendor/product needed","Integration layer needed","Not applicable"]
        disp_ops = list(dict.fromkeys(["Reuse existing","Extend existing","New capability needed","Duplicate risk","Retire/replace","Unknown","Not applicable", d.get("default_disposition","Unknown")]))
        action_ops = ["Validate default with SMEs","Reuse existing module","Extend existing module","Deep dive assessment","RFP/vendor product evaluation","Add to integration layer","Create roadmap item","Defer / future phase","Not applicable"]
        c1,c2 = st.columns(2)
        with c1:
            a["status"] = st.selectbox("Review status", status_ops, index=status_ops.index(a.get("status","Not reviewed")) if a.get("status") in status_ops else 0)
        with c2:
            a["availability"] = st.selectbox("Capability availability", avail_ops, index=avail_ops.index(a.get("availability","Unknown")) if a.get("availability") in avail_ops else 0)
        c3,c4 = st.columns(2)
        with c3:
            a["disposition"] = st.selectbox("Architecture disposition", disp_ops, index=disp_ops.index(a.get("disposition", d.get("default_disposition","Unknown"))) if a.get("disposition", d.get("default_disposition","Unknown")) in disp_ops else 0)
        with c4:
            a["action"] = st.selectbox("Recommended action", action_ops, index=action_ops.index(a.get("action","Validate default with SMEs")) if a.get("action") in action_ops else 0)
        a["owner"] = st.text_input("Owner / SME", a.get("owner",""))
        a["risks"] = st.text_area("Risks / controls to validate", a.get("risks",""), height=75)
        a["integrations"] = st.text_area("Integration / platform impact", a.get("integrations",""), height=75)
        a["decision"] = st.text_area("Decision needed", a.get("decision",""), height=75)
        a["notes"] = st.text_area("Architecture notes / rationale", a.get("notes",""), height=75)
    else:
        b = payload["business_input"].get(mid, {})
        a = payload["architecture_review"].get(mid, {})
        st.markdown("##### Business input")
        st.json({"Need": b.get("need",""), "Today": b.get("today",""), "Pain": b.get("pain",""), "Priority": b.get("priority",""), "Questions": b.get("questions","")})
        st.markdown("##### Architecture review")
        st.json({"Status": a.get("status",""), "Availability": a.get("availability",""), "Disposition": a.get("disposition",""), "Action": a.get("action",""), "Owner": a.get("owner",""), "Decision": a.get("decision",""), "Notes": a.get("notes","")})


# -----------------------------
# Document extraction automation
# -----------------------------

MODULE_KEYWORDS = {
    "channels": ["online", "mobile", "portal", "digital", "workspace", "branch", "ux", "user experience", "customer experience"],
    "contact_center": ["contact center", "call center", "customer service", "service center", "support", "agent"],
    "communications": ["notice", "alert", "email", "sms", "message", "statement", "communication", "letter"],
    "marketing": ["campaign", "offer", "lead", "cross-sell", "marketing", "growth", "target segment"],
    "customer": ["customer", "client", "party", "relationship", "household", "business entity", "signer", "owner", "guarantor"],
    "onboarding": ["onboarding", "kyc", "kyb", "cip", "ofac", "beneficial owner", "due diligence", "application", "intake"],
    "product_pricing": ["product", "pricing", "fee", "rate", "waiver", "eligibility", "package", "price"],
    "deposit_account_servicing": ["deposit", "checking", "savings", "account opening", "account maintenance", "overdraft", "nsf", "stop payment", "dormancy", "statement"],
    "lending": ["loan", "credit", "underwriting", "approval", "origination", "booking", "covenant", "renewal", "line of credit"],
    "treasury_payments": ["treasury", "payment", "ach", "wire", "rtp", "fednow", "lockbox", "positive pay", "remote deposit", "controlled disbursement", "sweep", "liquidity"],
    "cards_servicing": ["card", "credit card", "debit card", "p-card", "purchasing card", "chargeback", "dispute", "rewards", "card controls"],
    "collateral": ["collateral", "borrowing base", "inventory", "accounts receivable", "ar", "valuation", "lien", "field exam", "asset"],
    "capital_markets_advisory": ["capital markets", "fx", "foreign exchange", "swap", "hedging", "trade finance", "syndication", "m&a", "advisory"],
    "operations": ["operations", "fulfillment", "manual", "back office", "reconciliation", "exception", "sla", "handoff"],
    "collections_recovery": ["collections", "recovery", "delinquency", "hardship", "loss mitigation", "charge-off", "bankruptcy", "foreclosure", "workout"],
    "workflow": ["workflow", "case", "task", "approval", "queue", "routing", "escalation", "review"],
    "risk_compliance": ["risk", "compliance", "fraud", "aml", "sanction", "control", "audit", "regulatory", "fair lending", "udaap"],
    "documents": ["document", "esign", "signature", "agreement", "disclosure", "retention", "repository", "evidence"],
    "data_ai": ["data", "report", "analytics", "dashboard", "metric", "kpi", "ai", "model", "insight", "lineage"],
    "finance_billing": ["billing", "gl", "general ledger", "revenue", "fee", "profitability", "cost", "reconcile", "accounting"],
    "identity_security": ["access", "role", "entitlement", "security", "mfa", "sso", "permission", "dual control", "audit log"],
    "integration": ["api", "integration", "event", "file", "batch", "real-time", "interface", "data contract", "system"]
}

STARTING_POINT_HINTS = {
    "Small Business Banking": ["small business", "smb", "business owner", "business banking"],
    "TM Payments": ["treasury management", "tm", "payments", "cash management"],
    "ABL": ["asset based lending", "abl", "borrowing base", "collateral monitoring"],
    "Mortgage": ["mortgage", "home loan", "closing disclosure", "escrow"],
    "Mortgage Servicing": ["mortgage servicing", "escrow", "payoff", "loss mitigation"],
    "Collections / Recovery": ["collections", "recovery", "delinquency", "charge-off", "loss mitigation"],
    "Consumer / Retail Banking": ["consumer banking", "retail banking", "personal banking"],
    "Personal Checking & Savings": ["personal checking", "personal savings", "consumer deposit"],
    "Business Checking & Savings": ["business checking", "business savings", "business deposit"],
    "Business Online Banking": ["business online banking", "online banking", "digital banking"],
    "Positive Pay / Fraud Protection": ["positive pay", "fraud protection", "fraud prevention"],
    "Purchasing Card": ["purchasing card", "p-card", "commercial card"],
    "Business Credit Cards": ["business credit card", "commercial credit card"],
    "Personal Credit Cards": ["personal credit card", "consumer credit card"],
    "Debit Card / Card Management": ["debit card", "card controls", "digital wallet"],
    "SBA Lending": ["sba", "7(a)", "504", "sba express"],
    "Commercial Real Estate Lending": ["commercial real estate", "cre", "investment real estate"],
    "Loan Syndications": ["loan syndication", "syndicated loan", "agency"],
    "International Banking / FX": ["international banking", "foreign exchange", "fx", "global payment"],
    "Trade Finance": ["trade finance", "letter of credit", "export", "import"],
    "Interest Rate Swaps / Hedging": ["interest rate swap", "hedging", "swap"],
    "Investment Banking / M&A Advisory": ["investment banking", "m&a", "merger", "acquisition", "valuation"],
    "Wealth Management": ["wealth management", "investment management", "financial planning"],
    "Private Banking": ["private banking", "affluent", "high net worth"],
    "Insurance": ["insurance", "policy", "carrier", "claim"],
    "Government / Public Finance": ["government banking", "public finance", "municipal"],
}

def clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

def extract_text_from_upload(uploaded_file) -> Tuple[str, str]:
    name = uploaded_file.name.lower()
    raw = uploaded_file.getvalue()

    if name.endswith((".txt", ".md", ".csv")):
        for enc in ["utf-8", "latin-1"]:
            try:
                return clean_text(raw.decode(enc)), "text"
            except Exception:
                pass
        return "", "unsupported text encoding"

    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(raw))
            pages = []
            for page in reader.pages:
                pages.append(page.extract_text() or "")
            return clean_text("\n\n".join(pages)), "pdf"
        except Exception as e:
            return "", f"pdf extraction failed: {e}"

    if name.endswith(".docx"):
        try:
            from docx import Document
            doc = Document(io.BytesIO(raw))
            parts = [p.text for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    cells = [c.text.strip() for c in row.cells if c.text.strip()]
                    if cells:
                        parts.append(" | ".join(cells))
            return clean_text("\n".join(parts)), "docx"
        except Exception as e:
            return "", f"docx extraction failed: {e}"

    if name.endswith((".xlsx", ".xls")):
        try:
            xls = pd.ExcelFile(io.BytesIO(raw))
            parts = []
            for sheet in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet)
                parts.append(f"Sheet: {sheet}")
                parts.append(df.astype(str).head(200).to_csv(index=False))
            return clean_text("\n".join(parts)), "spreadsheet"
        except Exception as e:
            return "", f"spreadsheet extraction failed: {e}"

    return "", "unsupported file type"

def split_sentences(text: str) -> List[str]:
    text = re.sub(r"\s+", " ", text)
    parts = re.split(r"(?<=[.!?])\s+|[\n\r]+", text)
    return [p.strip() for p in parts if len(p.strip()) > 20]

def first_title_line(text: str) -> str:
    for line in text.splitlines():
        s = line.strip(" -:\t")
        if 8 <= len(s) <= 120 and not s.lower().startswith(("table of contents", "confidential")):
            return s[:100]
    sentences = split_sentences(text)
    return (sentences[0][:100] if sentences else "")

def find_labeled_value(text: str, labels: List[str]) -> str:
    for label in labels:
        pattern = rf"(?im)^\s*{re.escape(label)}\s*[:\-]\s*(.+)$"
        m = re.search(pattern, text)
        if m:
            return m.group(1).strip()[:160]
    return ""

def relevant_sentences(text: str, keywords: List[str], limit: int = 3) -> List[str]:
    sentences = split_sentences(text)
    scored = []
    lower_keywords = [k.lower() for k in keywords]
    for s in sentences:
        sl = s.lower()
        score = sum(1 for k in lower_keywords if k in sl)
        if score:
            scored.append((score, len(s), s))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [s for _, _, s in scored[:limit]]

def infer_starting_point(data: Dict[str, Any], text: str) -> Tuple[str, List[Tuple[str, int]]]:
    t = text.lower()
    scores = {}
    for item_name, item_def in data["items"].items():
        corpus = f"{item_name} {item_def.get('summary','')} {item_def.get('notes','')}".lower()
        tokens = sorted(set(re.findall(r"[a-zA-Z][a-zA-Z0-9/&-]{2,}", corpus)))
        score = 0
        for tok in tokens:
            if tok in t:
                score += 1
        for phrase in STARTING_POINT_HINTS.get(item_name, []):
            if phrase.lower() in t:
                score += 12
        scores[item_name] = score
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    best = ranked[0][0] if ranked and ranked[0][1] > 0 else "Small Business Banking"
    return best, ranked[:8]

def infer_request_context(text: str, suggested_starting_point: str) -> Dict[str, str]:
    problem_sentences = relevant_sentences(
        text,
        ["need", "problem", "pain", "goal", "objective", "request", "requirement", "improve", "reduce", "increase", "replace", "manual", "risk"],
        limit=4
    )
    target_sentences = relevant_sentences(
        text,
        ["customer", "client", "banker", "relationship manager", "operations", "contact center", "user", "employee", "small business", "commercial"],
        limit=2
    )
    return {
        "name": find_labeled_value(text, ["Request Name", "Project Name", "Initiative", "Title"]) or first_title_line(text) or suggested_starting_point,
        "sponsor": find_labeled_value(text, ["Sponsor", "LOB", "Line of Business", "Business Owner", "Product Owner", "Requestor"]),
        "request_type": "Vendor / RFP evaluation" if re.search(r"\brfp\b|request for proposal|vendor", text, re.I) else "New product / service",
        "target_users": find_labeled_value(text, ["Target Users", "Users", "Audience"]) or " ".join(target_sentences)[:250],
        "problem": " ".join(problem_sentences)[:1000]
    }

def infer_added_modules(data: Dict[str, Any], payload: Dict[str, Any], text: str) -> List[str]:
    selected = payload["selected_starting_point"]
    defaults = default_ids(data, selected)
    t = text.lower()
    additions = []
    for mid in [m["id"] for m in data["modules"]]:
        if mid in defaults:
            continue
        keywords = MODULE_KEYWORDS.get(mid, [])
        score = sum(1 for k in keywords if k.lower() in t)
        if score >= 2:
            additions.append(mid)
    return additions

def infer_module_business_inputs(data: Dict[str, Any], payload: Dict[str, Any], text: str) -> Dict[str, Dict[str, str]]:
    output = {}
    for mid in in_scope_ids(data, payload):
        module = module_by_id(data, mid)
        keywords = MODULE_KEYWORDS.get(mid, [])
        keywords = keywords + [module["name"].lower()]
        sents = relevant_sentences(text, keywords, limit=3)
        pain_sents = [s for s in sents if re.search(r"manual|pain|gap|missing|issue|problem|risk|delay|duplicate|broken|not available|cannot|need", s, re.I)]
        output[mid] = {
            "need": " ".join(sents[:2])[:800],
            "today": "",
            "pain": " ".join(pain_sents[:2])[:600],
            "priority": "Must-have" if sents else "Unknown",
            "questions": ""
        }
    return output

def apply_document_extraction(data: Dict[str, Any], payload: Dict[str, Any], text: str, overwrite: bool = False) -> Dict[str, Any]:
    suggested, ranked = infer_starting_point(data, text)
    payload["selected_starting_point"] = suggested
    payload["selected_type"] = item(data, suggested)["type"]
    if overwrite:
        payload["business_input"] = {}
        payload["architecture_review"] = {}
        payload["added_modules"] = []
    payload = ensure_records(data, payload)

    ctx = infer_request_context(text, suggested)
    for k, v in ctx.items():
        if overwrite or not payload["request_context"].get(k):
            payload["request_context"][k] = v

    additions = infer_added_modules(data, payload, text)
    for mid in additions:
        if mid not in payload.setdefault("added_modules", []):
            payload["added_modules"].append(mid)

    payload = ensure_records(data, payload)
    module_inputs = infer_module_business_inputs(data, payload, text)
    for mid, inferred in module_inputs.items():
        existing = payload["business_input"].setdefault(mid, {})
        for k, v in inferred.items():
            if overwrite or not existing.get(k):
                existing[k] = v

    payload["source_document"] = {
        "extracted_at": now_iso(),
        "suggested_starting_point": suggested,
        "top_starting_point_matches": ranked,
        "extracted_text_preview": text[:5000],
        "extracted_text_length": len(text)
    }
    return payload

def render_document_intake_panel(data: Dict[str, Any], payload: Dict[str, Any]):
    with st.expander("Optional document prefill: upload RFP / BRD / intake document", expanded=False):
        st.markdown('<div class="compact-note">Extract text locally and create a first draft. Architecture still validates the output.</div>', unsafe_allow_html=True)

        uploaded = st.file_uploader(
            "Upload document",
            type=["pdf", "docx", "txt", "md", "csv", "xlsx", "xls"],
            key="doc_upload",
            label_visibility="collapsed"
        )
        overwrite = st.checkbox("Overwrite current draft fields with extracted values", value=False)

        if uploaded is not None:
            text, kind = extract_text_from_upload(uploaded)
            if not text:
                st.error(f"Could not extract text: {kind}")
                return payload

            suggested, ranked = infer_starting_point(data, text)
            c1, c2 = st.columns([1, 1])
            with c1:
                st.success(f"Extracted {len(text):,} characters from {uploaded.name}")
                st.write(f"Suggested starting point: **{suggested}**")
            with c2:
                st.caption("Top matches")
                st.dataframe(pd.DataFrame(ranked, columns=["Starting point", "Score"]), hide_index=True, use_container_width=True, height=180)

            with st.expander("Preview extracted text", expanded=False):
                st.text_area("Text preview", text[:5000], height=180)

            if st.button("Apply document extraction to this request", type="primary", use_container_width=True):
                payload = apply_document_extraction(data, payload, text, overwrite=overwrite)
                st.session_state.payload = payload
                st.session_state.selected_module = next(iter(in_scope_ids(data, payload)), None)
                st.success("Document extraction applied. Review the request context and clicked module dossiers.")
                st.rerun()

    return payload

def main():
    st.set_page_config(page_title="Banking Business Architecture Intake", page_icon="🏦", layout="wide")
    css()
    init_db()
    data = load_data()
    if "payload" not in st.session_state:
        st.session_state.payload = blank_payload(data)
    if "selected_module" not in st.session_state:
        st.session_state.selected_module = next(iter(in_scope_ids(data, st.session_state.payload)), None)

    st.markdown("""
<div class="app-header">
  <div class="app-title">Banking Business Architecture Intake v10 — Compact Clickable Tiles</div>
  <div class="subtitle">Compact HTML-style Streamlit version: tiles are clickable, no separate Open buttons, document prefill is collapsed, and requests still save to SQLite for architecture review.</div>
</div>
""", unsafe_allow_html=True)

    with st.sidebar:
        st.header("Workspace")
        workspace = st.radio("Workspace", ["Create / edit request", "Architecture review queue", "Export / admin"], label_visibility="collapsed")
        role_mode = st.radio("Dossier mode", ["Business input", "Architecture review", "Summary"])
        st.caption("Local database")
        st.code(str(DB_FILE), language="text")

    if workspace == "Architecture review queue":
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Architecture review queue")
        status_filter = st.selectbox("Filter", ["All"] + STATUS_OPTIONS)
        df = list_requests(status_filter)
        st.dataframe(df, use_container_width=True, hide_index=True)
        if not df.empty:
            options = df["request_id"].tolist()
            rid = st.selectbox("Open request", options, format_func=lambda x: f"{df.loc[df['request_id']==x, 'title'].iloc[0]} · {x[:8]}")
            c1,c2 = st.columns([1,1])
            with c1:
                if st.button("Open selected request", type="primary", use_container_width=True):
                    st.session_state.payload = ensure_records(data, load_request(rid))
                    st.session_state.selected_module = next(iter(in_scope_ids(data, st.session_state.payload)), None)
                    st.rerun()
            with c2:
                if st.button("Delete selected request", use_container_width=True):
                    delete_request(rid)
                    st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)
        return

    if workspace == "Export / admin":
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Export / admin")
        df = list_requests("All")
        st.dataframe(df, use_container_width=True, hide_index=True)
        if not df.empty:
            payloads = [load_request(rid) for rid in df["request_id"]]
            st.download_button("Download all requests JSON", json.dumps(payloads, indent=2), "architecture_requests_export.json", "application/json")
            rows = []
            for p in payloads:
                rows += export_rows(data, p)
            if rows:
                st.download_button("Download all module reviews CSV", pd.DataFrame(rows).to_csv(index=False), "architecture_module_reviews.csv", "text/csv")
        st.markdown('</div>', unsafe_allow_html=True)
        return

    payload = ensure_records(data, st.session_state.payload)
    process_tile_query_params(data, payload)
    st.session_state.payload = payload

    # Top controls
    top1, top2, top3 = st.columns([2.2, .9, .9])
    with top1:
        starts = list(data["items"].keys())
        idx = starts.index(payload["selected_starting_point"]) if payload["selected_starting_point"] in starts else 0
        new_start = st.selectbox("Starting point", starts, idx)
        if new_start != payload["selected_starting_point"]:
            payload["selected_starting_point"] = new_start
            payload["selected_type"] = item(data, new_start)["type"]
            payload["added_modules"] = []
            payload["business_input"] = {}
            payload["architecture_review"] = {}
            ensure_records(data, payload)
            st.session_state.selected_module = next(iter(in_scope_ids(data, payload)), None)
            st.rerun()
    with top2:
        payload["status"] = st.selectbox("Status", STATUS_OPTIONS, index=STATUS_OPTIONS.index(payload.get("status","Draft")) if payload.get("status") in STATUS_OPTIONS else 0)
    with top3:
        if st.button("New blank request", use_container_width=True):
            st.session_state.payload = blank_payload(data)
            st.session_state.selected_module = next(iter(in_scope_ids(data, st.session_state.payload)), None)
            st.rerun()

    it = item(data, payload["selected_starting_point"])
    st.markdown(f"""
<div class="banner">
  <div>
    <div class="banner-title">{payload["selected_starting_point"]}</div>
    <div class="banner-text">{it.get("summary","")} {it.get("notes","")}</div>
  </div>
  <div class="type-tag">{it.get("type","")}</div>
</div>
""", unsafe_allow_html=True)

    render_metrics(data, payload)

    left, right = st.columns([1.55, 1], gap="large")
    with left:
        with st.container(border=True):
            payload = render_document_intake_panel(data, payload)
            st.session_state.payload = payload
        with st.container(border=True):
            request_context(payload)
        with st.container(border=True):
            st.markdown('<div class="section-title">2. Module dependency map</div>', unsafe_allow_html=True)
            st.markdown('<div class="small-muted">Click any tile to open it. Click a faded tile to add it to scope.</div>', unsafe_allow_html=True)
            render_map(data, payload)
    with right:
        with st.container(border=True):
            render_dossier(data, payload, role_mode)

    st.divider()
    c1,c2,c3,c4 = st.columns(4)
    with c1:
        if st.button("Save request", type="primary", use_container_width=True):
            rid = save_payload(payload)
            st.session_state.payload = ensure_records(data, load_request(rid))
            st.success(f"Saved: {rid}")
    with c2:
        if st.button("Save + Submit", use_container_width=True):
            payload["status"] = "Submitted"
            rid = save_payload(payload)
            st.session_state.payload = ensure_records(data, load_request(rid))
            st.success(f"Submitted: {rid}")
    with c3:
        st.download_button("Download JSON", json.dumps(payload, indent=2), f"request_{payload.get('request_id') or 'draft'}.json", "application/json", use_container_width=True)
    with c4:
        st.download_button("Download CSV", pd.DataFrame(export_rows(data, payload)).to_csv(index=False), f"module_review_{payload.get('request_id') or 'draft'}.csv", "text/csv", use_container_width=True)

if __name__ == "__main__":
    main()
