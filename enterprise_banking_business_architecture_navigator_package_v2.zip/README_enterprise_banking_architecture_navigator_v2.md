# Enterprise Banking Business Architecture Navigator Package

Version: v2.0  
Created: 2026-06-05

## What this package contains

This package includes the updated artifacts for the business architecture we discussed:

1. **Interactive HTML Navigator**
   - `enterprise_banking_business_architecture_navigator_v2.html`
   - Executive-to-detail business architecture view
   - Includes CEO, LOB Head, Product Manager, Architecture, Risk, Data/AI, Operations, and Technology perspectives

2. **Editable Excel Content Model**
   - `enterprise_banking_business_architecture_content_model_v2.xlsx`
   - Sheets include:
     - Dashboard
     - Audience_Altitude
     - Altitude_Views
     - Architecture_Views
     - Segments
     - Value_Streams
     - Capability_Map
     - Product_RFP_Lens
     - Experience_UIUX
     - Information_Model
     - Decisions_AI
     - Operating_Model
     - Enabling_Platforms
     - Checklist
     - Principles
     - Sources

3. **JSON Runtime Data Feed**
   - `enterprise_banking_business_architecture_data_v2.json`
   - Data used by the HTML navigator
   - HTML also has embedded starter data so it can open standalone

4. **One-Page Executive Visual**
   - `enterprise_banking_business_architecture_one_page_visual.svg`
   - Single image showing the architecture from strategy to platforms and product/RFP lens

5. **Narrative Playbook**
   - `enterprise_banking_business_architecture_playbook_v2.md`
   - Explains how to use the navigator with different audiences

## How to use

### Option 1: Open HTML directly
Open `enterprise_banking_business_architecture_navigator_v2.html` in a browser.

The HTML has the data embedded, so it works standalone.

### Option 2: Load external JSON
Open the HTML, go to **Sources & Update**, and upload `enterprise_banking_business_architecture_data_v2.json`.

### Option 3: Edit content
Use the Excel workbook as the editable content model. After edits, the JSON feed should be regenerated to refresh the HTML.

## What changed in v2

This version includes the fuller business architecture we discussed:

- 100,000 ft to 1,000 ft presentation flow
- CEO-to-product-manager audience model
- Business architecture views
- Consumer, small business, commercial, treasury, wealth, and internal segments
- Banking value streams
- Enterprise capability map
- ABL product/RFP assessment lens
- UI/UX as both experience layer and reusable capability
- Data, AI, and decision architecture
- Operating model ownership
- Enabling platform view
- Workshop checklist
- Principles and industry reference sources

## Suggested future enhancement

For enterprise use, move the editable source from Excel to SharePoint Lists, Dataverse, or an EA repository. Keep Excel as the bulk-edit/import-export layer.
