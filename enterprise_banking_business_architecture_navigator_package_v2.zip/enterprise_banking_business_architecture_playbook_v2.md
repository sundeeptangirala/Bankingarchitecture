# Enterprise Banking Business Architecture Navigator — Playbook

Version: v2.0  
Created: 2026-06-05

## Purpose

This package is a living business architecture navigator for evaluating products, platforms, RFPs, vendor proposals, and LOB change requests across the bank.

It is designed to support conversations from CEO / executive altitude down to LOB product manager and delivery detail.

## Core message

Start with business architecture, not applications:

1. Business strategy and outcomes
2. Segments and stakeholders
3. Value streams
4. Business capabilities
5. Experience / UI/UX architecture
6. Information model
7. Decision / AI architecture
8. Operating ownership
9. Enabling platforms and systems
10. Product / RFP intake lens

## Key principle

Every product should consume shared enterprise capabilities unless there is a clear business reason to extend or create something new.

## How to use in meetings

### CEO / Executive Committee

Use the one-page visual and Executive Summary tab to explain the bank-wide discipline:

- Reduce duplicate capabilities
- Improve customer and employee experience
- Improve risk and control visibility
- Reuse shared platforms
- Make investments based on business capability gaps

### LOB Head

Use Segments, Value Streams, Capability Map, and Operating Model:

- Which segment are we serving?
- Which value stream changes?
- What capabilities are shared vs specialized?
- Who owns each capability?

### Product Manager / RFP Team

Use Product / RFP Lens and Checklist:

- What capabilities does the product require?
- Which are reused, extended, new, duplicate, or retired?
- What is truly unique to this product?
- What UX, data, AI, risk, and platform impacts exist?

### Enterprise Architecture / Technology

Use Capability Map and Enabling Platforms:

- Which systems enable the capability?
- Are we creating point-to-point integrations?
- What APIs/events/data contracts are required?
- Is the vendor duplicating existing enterprise capabilities?

### Risk / Compliance / Audit

Use Decision / AI, Checklist, and Operating Model:

- Which controls apply?
- Which decisions are rules-based, model-based, or AI-assisted?
- What evidence and audit trail are required?
- Who owns the risk and control model?

### Data / AI / Analytics

Use Information Model, Decisions AI, Capability Map, and Product Lens:

- What business objects are created or changed?
- Which metrics need enterprise definitions?
- Which AI/model use cases are embedded?
- What model risk, explainability, monitoring, and human review are needed?

## Files in this package

- `enterprise_banking_business_architecture_navigator_v2.html` — interactive HTML navigator
- `enterprise_banking_business_architecture_content_model_v2.xlsx` — editable Excel content model
- `enterprise_banking_business_architecture_data_v2.json` — runtime data feed for HTML
- `enterprise_banking_business_architecture_one_page_visual.svg` — one-image executive visual
- `enterprise_banking_business_architecture_playbook_v2.md` — narrative playbook
- `README_enterprise_banking_architecture_navigator_v2.md` — technical usage notes

## Content model guidance

The Excel workbook is the business-friendly editing template. The JSON is what the HTML reads at runtime.

For now, update flow is:

Excel content model → JSON runtime feed → HTML navigator

A future enterprise version should move the source repository to SharePoint Lists, Dataverse, or an EA tool, while keeping Excel as import/export and bulk edit layer.
