# Business Architecture Intake v5 — Business Input + Architecture Defaults

This version implements the corrected model:

- Business users enter what they need and what they know.
- Architecture starts with default assumptions and validates or overrides them.

## Flow

1. Select a starting point:
   - Small Business Banking
   - TM Payments
   - ABL
   - ACH
   - Wires
   - Commercial Onboarding
   - etc.

2. Dependency map highlights relevant modules.

3. Business request input captures:
   - Request name
   - LOB/sponsor
   - Request type
   - Target users
   - Business problem
   - Expected outcome
   - Current-state pain/constraints

4. For each highlighted module, there are two lanes:

### Business Input Lane
Business enters:
- What does this request need from this module?
- What exists today?
- What is painful or missing today?
- Who is involved today?
- Business priority
- Open questions

### Architecture Default + Review Lane
Architecture receives prefilled defaults:
- Default disposition
- Likely owners
- Likely risks
- Likely integrations
- Default review question

Architecture then confirms or overrides:
- Review status
- Final/proposed disposition
- Impact level
- Owner/SME
- Risks/controls to validate
- Integration/platform impact
- Decision needed
- Next action
- Architecture notes

## Why this version is better

The business team is not forced to make architecture decisions.  
The architecture team does not start with a blank page.  
The tool provides a default banking point of view that can be validated or changed.

## Files

- `enterprise_banking_business_architecture_intake_assessment_v5_defaults.html`
- `enterprise_banking_business_architecture_intake_assessment_v5_data.json`
- `README_enterprise_banking_business_architecture_intake_assessment_v5.md`
