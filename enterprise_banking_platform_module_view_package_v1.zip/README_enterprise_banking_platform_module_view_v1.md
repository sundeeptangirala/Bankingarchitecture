# Enterprise Banking Platform Module View v1

Open `enterprise_banking_platform_module_view_v1.html` in Chrome or Edge.

Use this view after the business architecture conversation, when you want to explain how bank capabilities become reusable platform modules.

## Tabs
- Executive Platform View: one-page layered story for CEO/LOB heads
- Platform Modules: clickable module cards
- Product/RFP Lens: select ABL, Small Business Lending, Treasury Product, etc. and view module impact
- Module Dependency Map: visual swimlane view
- Reuse Governance: rules and questions for architecture review

## Core question
For every product, RFP, vendor, or LOB request:
- Which modules are reused?
- Which modules are extended?
- Which modules are new?
- Which modules are duplicated?
- Which modules can be retired?
