# Banking Platform Module Dependency View v1

This package contains a simplified interactive banking platform-module map.

## Main file
Open:

- `banking_platform_module_dependency_view_v1.html`

## What it does
- Shows all platform modules at all times.
- Lets you select a banking product, service, journey, or LOB/segment.
- Highlights modules as:
  - Primary / core dependency
  - Supporting / commonly needed
  - Optional / situational
  - Faded / not central
- Click any module card to see detail.

## Design logic
This is meant as a discussion model, not a detailed engineering diagram.

The module map intentionally avoids actual application/vendor names and detailed sub-capabilities in the first-level view.

## Files
- `banking_platform_module_dependency_view_v1.html`: interactive HTML
- `banking_platform_module_dependency_data_v1.json`: content/data model embedded in the HTML
- `README_banking_platform_module_dependency_view_v1.md`: usage notes
