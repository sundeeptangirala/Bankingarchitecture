# Enterprise Banking Business Architecture Intake Assessment v2

This version changes the intake assessment to be driven by the Platform Module Dependency View.

## What changed from v1
The intake is no longer a generic architecture checklist.

It now works like this:

1. Select a banking product/function/LOB such as TM Payments, ABL, Commercial Onboarding, ACH, Wires, Small Business Banking, etc.
2. The platform modules needed for that selection light up.
3. The assessment is generated only for the relevant modules.
4. Each module is assessed for:
   - What do we know?
   - Reuse / extend / new / duplicate / retire / unknown
   - Owner / SME
   - Evidence / artifact
   - Notes / gaps
5. The tool calculates readiness and gap count.
6. Export JSON or CSV for follow-up.

## Main file
Open:
- `enterprise_banking_business_architecture_intake_assessment_v2.html`

## Data file
- `enterprise_banking_business_architecture_intake_assessment_v2_data.json`

## Design principle
Business architecture drives the discussion. The platform module dependency map drives the intake. User input comes after the map, not before it.
