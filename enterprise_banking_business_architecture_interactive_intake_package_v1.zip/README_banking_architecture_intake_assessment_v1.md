# Enterprise Banking Business Architecture Intake Assessment Tool v1

This package turns the business architecture navigator into an interactive intake and assessment workflow.

## What it does

Users bringing a business problem, product idea, vendor, platform, RFP, or solution can fill out:

- Request name, sponsor, problem statement, proposed solution, outcomes
- Impacted segments and value streams
- Capability impact: No impact, Unknown, Reuse, Extend, New, Duplicate, Retire
- Knowledge checklist: Known, Partially known, Unknown, Not applicable
- Owners, evidence, notes, and gaps

The tool then produces:

- Readiness score
- Unknown/gap list
- Duplicate capability red flags
- Recommended next action
- Exportable report
- Capability CSV
- Full JSON assessment export/import

## How to use

1. Open `enterprise_banking_business_architecture_intake_assessment_v1.html` in Chrome or Edge.
2. Use it live in a discovery meeting.
3. Ask the LOB/product/vendor team to fill in what they know and mark Unknown where they do not know.
4. Use the Readiness + Gaps view to decide whether the request is ready for architecture review, needs discovery, or has duplicate-capability red flags.
5. Export the report as JSON, CSV, copied text, or print/save as PDF.

## Recommended enterprise path

MVP:
- Standalone HTML with local browser storage and JSON export.

Team use:
- Store submissions in SharePoint Lists or Dataverse.
- Use Power Apps or internal forms for controlled editing.

Governed use:
- Add approvals, versioning, evidence links, ownership, audit trails, and role-based access.
- Connect to LeanIX, Ardoq, ServiceNow, Jira, or an internal EA repository if available.

Executive reporting:
- Use Power BI to show reuse rate, duplicate-risk heatmap, readiness by product, capability gaps, and owner assignment completeness.

## Important note

The prototype is browser-only. If opened locally, the data stays in the browser unless the user exports a file. For bank-wide use, host internally and connect the submission store to an approved enterprise repository.
