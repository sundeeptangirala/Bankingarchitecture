
import json
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Set

import pandas as pd
import streamlit as st

APP_DIR = Path(__file__).parent
DATA_FILE = APP_DIR / "architecture_data.json"
DB_FILE = APP_DIR / "architecture_requests.db"
LAYER_ORDER = ["Experience / Engagement", "Business Core", "Enterprise Shared"]

STATUS_OPTIONS = ["Draft", "Submitted", "In Architecture Review", "Needs Business Follow-up", "Decision Required", "Approved", "Closed"]
REQUEST_TYPES = ["New product / service", "Enhancement to existing capability", "Vendor / RFP evaluation", "Process improvement", "Risk / compliance need", "Data / AI use case", "Other"]

def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

@st.cache_data
def load_data() -> Dict[str, Any]:
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))

def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS requests (
          request_id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          sponsor TEXT,
          selected_starting_point TEXT NOT NULL,
          selected_type TEXT,
          status TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          payload_json TEXT NOT NULL
        )
        """)
        conn.commit()

def save_payload(payload: Dict[str, Any]) -> str:
    init_db()
    rid = payload.get("request_id") or str(uuid.uuid4())
    payload["request_id"] = rid
    payload.setdefault("created_at", now_iso())
    payload["updated_at"] = now_iso()
    ctx = payload.get("request_context", {})
    title = ctx.get("name") or f"{payload.get('selected_starting_point', 'Request')} - {rid[:8]}"
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
        INSERT INTO requests(request_id,title,sponsor,selected_starting_point,selected_type,status,created_at,updated_at,payload_json)
        VALUES(?,?,?,?,?,?,?,?,?)
        ON CONFLICT(request_id) DO UPDATE SET
          title=excluded.title, sponsor=excluded.sponsor, selected_starting_point=excluded.selected_starting_point,
          selected_type=excluded.selected_type, status=excluded.status, updated_at=excluded.updated_at,
          payload_json=excluded.payload_json
        """, (
            rid, title, ctx.get("sponsor",""), payload.get("selected_starting_point",""), payload.get("selected_type",""),
            payload.get("status","Draft"), payload.get("created_at", now_iso()), payload["updated_at"], json.dumps(payload)
        ))
        conn.commit()
    return rid

def list_requests(status="All") -> pd.DataFrame:
    init_db()
    q = "SELECT request_id,title,sponsor,selected_starting_point,selected_type,status,created_at,updated_at FROM requests"
    params = ()
    if status != "All":
        q += " WHERE status=?"
        params = (status,)
    q += " ORDER BY updated_at DESC"
    with sqlite3.connect(DB_FILE) as conn:
        return pd.read_sql_query(q, conn, params=params)

def load_request(rid: str) -> Dict[str, Any]:
    init_db()
    with sqlite3.connect(DB_FILE) as conn:
        row = conn.execute("SELECT payload_json FROM requests WHERE request_id=?", (rid,)).fetchone()
    if not row:
        raise ValueError("Request not found")
    return json.loads(row[0])

def delete_request(rid: str):
    init_db()
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("DELETE FROM requests WHERE request_id=?", (rid,))
        conn.commit()

def item(data, selected):
    return data["items"][selected]

def module_by_id(data, mid):
    return next(m for m in data["modules"] if m["id"] == mid)

def default_relevant(data, selected) -> List[Dict[str, str]]:
    it = item(data, selected)
    return ([{"id": x, "state": "primary"} for x in it.get("primary", [])] +
            [{"id": x, "state": "supporting"} for x in it.get("supporting", [])] +
            [{"id": x, "state": "optional"} for x in it.get("optional", [])])

def default_ids(data, selected) -> Set[str]:
    return {x["id"] for x in default_relevant(data, selected)}

def in_scope_ids(data, payload) -> Set[str]:
    return default_ids(data, payload["selected_starting_point"]) | set(payload.get("added_modules", []))

def dep_state(data, payload, mid) -> str:
    selected = payload["selected_starting_point"]
    it = item(data, selected)
    if mid in it.get("primary", []): return "primary"
    if mid in it.get("supporting", []): return "supporting"
    if mid in it.get("optional", []): return "optional"
    if mid in payload.get("added_modules", []): return "added"
    return "dimmed"

def defaults_for(data, payload, mid):
    return data.get("architecture_defaults", {}).get(payload["selected_starting_point"], {}).get(mid, {
        "default_disposition": "Unknown",
        "likely_owners": "",
        "likely_risks": "",
        "likely_integrations": "",
        "review_question": "What should the architecture team decide for this module?"
    })

def helper_for(data, mid):
    return data.get("module_helpers", {}).get(mid, "Enter what this request needs from this module.")

def blank_payload(data, selected="Small Business Banking"):
    if selected not in data["items"]:
        selected = list(data["items"].keys())[0]
    payload = {
        "request_id": "",
        "status": "Draft",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "selected_starting_point": selected,
        "selected_type": item(data, selected)["type"],
        "request_context": {
            "name": "",
            "sponsor": "",
            "request_type": "New product / service",
            "target_users": "",
            "problem": ""
        },
        "added_modules": [],
        "business_input": {},
        "architecture_review": {}
    }
    return ensure_records(data, payload)

def ensure_records(data, payload):
    payload.setdefault("added_modules", [])
    payload.setdefault("business_input", {})
    payload.setdefault("architecture_review", {})
    for mid in in_scope_ids(data, payload):
        payload["business_input"].setdefault(mid, {
            "need": "", "today": "", "pain": "", "priority": "Must-have", "questions": ""
        })
        d = defaults_for(data, payload, mid)
        payload["architecture_review"].setdefault(mid, {
            "status": "Not reviewed",
            "availability": "Unknown",
            "disposition": d.get("default_disposition", "Unknown"),
            "action": "Validate default with SMEs",
            "owner": d.get("likely_owners", ""),
            "risks": d.get("likely_risks", ""),
            "integrations": d.get("likely_integrations", ""),
            "decision": d.get("review_question", ""),
            "notes": ""
        })
    return payload

def apply_default(data, payload, mid):
    d = defaults_for(data, payload, mid)
    old_notes = payload.get("architecture_review", {}).get(mid, {}).get("notes", "")
    payload["architecture_review"][mid] = {
        "status": "Default accepted",
        "availability": "Unknown",
        "disposition": d.get("default_disposition", "Unknown"),
        "action": "Validate default with SMEs",
        "owner": d.get("likely_owners", ""),
        "risks": d.get("likely_risks", ""),
        "integrations": d.get("likely_integrations", ""),
        "decision": d.get("review_question", ""),
        "notes": old_notes
    }

def business_done(payload, mid):
    b = payload.get("business_input", {}).get(mid, {})
    return any(str(b.get(k, "")).strip() for k in ["need","today","pain","questions"])

def arch_done(payload, mid):
    a = payload.get("architecture_review", {}).get(mid, {})
    return bool(a.get("status") and a.get("status") != "Not reviewed")

def counts(data, payload):
    ids = in_scope_ids(data, payload)
    return {
        "default": len(default_ids(data, payload["selected_starting_point"])),
        "added": len(payload.get("added_modules", [])),
        "business": sum(1 for mid in ids if business_done(payload, mid)),
        "architecture": sum(1 for mid in ids if arch_done(payload, mid)),
        "scope": len(ids)
    }

def export_rows(data, payload):
    rows = []
    for mid in sorted(in_scope_ids(data, payload)):
        m = module_by_id(data, mid)
        d = defaults_for(data, payload, mid)
        b = payload.get("business_input", {}).get(mid, {})
        a = payload.get("architecture_review", {}).get(mid, {})
        rows.append({
            "request_id": payload.get("request_id",""),
            "starting_point": payload["selected_starting_point"],
            "module": m["name"],
            "dependency_type": dep_state(data, payload, mid),
            "business_need": b.get("need",""),
            "today": b.get("today",""),
            "pain": b.get("pain",""),
            "priority": b.get("priority",""),
            "business_questions": b.get("questions",""),
            "default_disposition": d.get("default_disposition",""),
            "availability": a.get("availability",""),
            "disposition": a.get("disposition",""),
            "action": a.get("action",""),
            "owner": a.get("owner",""),
            "risks": a.get("risks",""),
            "integrations": a.get("integrations",""),
            "decision": a.get("decision",""),
            "notes": a.get("notes","")
        })
    return rows

def css():
    st.markdown("""
<style>
:root{
  --bg:#f5f7fb; --panel:#fff; --ink:#172033; --muted:#667085; --line:#d9e0eb;
  --primary:#123c69; --primary2:#1d5f99; --support:#4f82b8; --optional:#8fb3d3; --dim:#e7ebf2;
  --green:#2f855a; --amber:#b7791f; --red:#b83232; --purple:#6b46c1;
  --shadow:0 12px 30px rgba(18,60,105,.11);
}
.stApp {
  background:linear-gradient(180deg,#eef3fb 0%,#f7f9fc 40%,#f5f7fb 100%);
  color:var(--ink);
}
.block-container {padding-top: 1rem; max-width: 1500px;}
[data-testid="stSidebar"] {background:#ffffff;}
.app-header{
  background:rgba(255,255,255,.93); backdrop-filter:blur(10px);
  border:1px solid var(--line); border-radius:22px; padding:18px 22px; margin-bottom:18px;
  box-shadow:var(--shadow);
}
.app-title{font-size:25px;letter-spacing:-.03em;margin:0;font-weight:950;color:var(--ink);}
.subtitle{color:var(--muted);font-size:14px;line-height:1.4;margin-top:6px;max-width:1180px}
.banner{
  display:grid; grid-template-columns:1fr auto; gap:12px; align-items:center;
  background:#f8fbff; border:1px solid #d4e3f4; border-radius:18px; padding:14px 16px; margin-bottom:14px;
}
.banner-title{font-size:20px;font-weight:950}
.banner-text{color:var(--muted);font-size:13.5px;margin-top:4px;line-height:1.42}
.type-tag{border-radius:999px;padding:7px 10px;background:#eef6ff;color:var(--primary);font-size:12px;font-weight:850;border:1px solid #cbdff3;white-space:nowrap}
.panel{
  background:rgba(255,255,255,.95); border:1px solid var(--line); border-radius:22px; 
  box-shadow:var(--shadow); padding:18px; margin-bottom:18px;
}
.section-title{font-size:18px;font-weight:900;margin:0 0 8px;color:var(--ink)}
.small-muted{font-size:13px;color:var(--muted);line-height:1.42}
.legend-pill {
  display:inline-flex; gap:6px; align-items:center; font-size:12px; color:var(--muted); 
  background:#fff; border:1px solid var(--line); border-radius:999px; padding:6px 9px; margin:2px 4px 10px 0;
}
.dot{width:10px;height:10px;border-radius:50%;display:inline-block}
.metric-card{background:#f8fafc;border:1px solid #edf1f6;border-radius:15px;padding:11px;margin-bottom:8px}
.metric-number{font-size:24px;font-weight:950;color:var(--primary);line-height:1}
.metric-label{font-size:11px;color:var(--muted);font-weight:850;line-height:1.2;margin-top:4px}
.layer-title{font-size:13px;text-transform:uppercase;letter-spacing:.08em;font-weight:950;color:#4a5568;margin:18px 0 8px}
.module-card{min-height:108px;border:1px solid var(--line);border-radius:17px;padding:12px;background:#fff;transition:.16s ease;position:relative;overflow:hidden;box-shadow:0 6px 14px rgba(18,60,105,.06);margin-bottom:6px}
.module-name{font-weight:950;font-size:13px;line-height:1.18;margin-bottom:6px}
.module-desc{font-size:11.5px;line-height:1.3;color:var(--muted);padding-right:16px}
.badge{display:inline-block;margin-top:8px;font-size:9px;font-weight:950;text-transform:uppercase;border-radius:999px;padding:4px 7px}
.status-dot{position:absolute;right:9px;top:9px;width:9px;height:9px;border-radius:50%;background:#cbd5e1}
.default-box,.helper-box,.callout{border-radius:14px;padding:11px;font-size:13px;line-height:1.45;margin:10px 0}
.default-box{background:#fffaf0;border:1px solid #f1d7a8;color:#5a3b0a}
.helper-box{background:#f8fafc;border:1px solid #edf1f6;color:#475467}
.callout{background:#eefaf4;border:1px solid #b8e2ca;color:#174a31}
.stButton>button {
  border-radius:12px !important; font-weight:850 !important; border:1px solid var(--line) !important;
}
.stButton>button[kind="primary"] {
  background:var(--primary) !important; color:white !important;
}
div[data-testid="stVerticalBlockBorderWrapper"]{border-radius:22px !important}
</style>
""", unsafe_allow_html=True)

def card_html(name, desc, state, selected=False, bdone=False, adone=False):
    bg = {
        "primary": "linear-gradient(135deg,#123c69,#1d5f99)",
        "supporting": "#eef6ff",
        "optional": "#f7fbff",
        "added": "#f3edff",
        "dimmed": "#f3f5f8",
    }.get(state, "#fff")
    text = "#fff" if state == "primary" else "#172033"
    desc_color = "rgba(255,255,255,.82)" if state == "primary" else "#667085"
    border = "3px solid #f6ad55" if selected else "1px solid #d9e0eb"
    opacity = ".30" if state == "dimmed" else "1"
    badge_bg = "rgba(255,255,255,.18)" if state == "primary" else "#ffffffaa"
    badge_text = "#fff" if state == "primary" else "#172033"
    dot_color = "#cbd5e1"
    if bdone and adone: dot_color = "#6b46c1"
    elif bdone: dot_color = "#b7791f"
    elif adone: dot_color = "#2f855a"
    label = {"primary":"primary","supporting":"supporting","optional":"optional","added":"added","dimmed":"click add"}[state]
    return f"""
<div class="module-card" style="background:{bg};color:{text};border:{border};opacity:{opacity};">
  <span class="status-dot" style="background:{dot_color}"></span>
  <div class="module-name">{name}</div>
  <div class="module-desc" style="color:{desc_color};">{desc}</div>
  <span class="badge" style="background:{badge_bg};color:{badge_text};">{label}</span>
</div>
"""

def render_metrics(data, payload):
    c = counts(data, payload)
    cols = st.columns(4)
    vals = [("Default modules", c["default"]), ("Added modules", c["added"]), ("Business-filled", c["business"]), ("Architecture-reviewed", c["architecture"])]
    for col, (label, value) in zip(cols, vals):
        with col:
            st.markdown(f'<div class="metric-card"><div class="metric-number">{value}</div><div class="metric-label">{label}</div></div>', unsafe_allow_html=True)

def render_map(data, payload):
    st.markdown("""
<span class="legend-pill"><span class="dot" style="background:#123c69"></span>Primary</span>
<span class="legend-pill"><span class="dot" style="background:#4f82b8"></span>Supporting</span>
<span class="legend-pill"><span class="dot" style="background:#8fb3d3"></span>Optional</span>
<span class="legend-pill"><span class="dot" style="background:#6b46c1"></span>User-added</span>
<span class="legend-pill"><span class="dot" style="background:#e7ebf2"></span>Click to add</span>
""", unsafe_allow_html=True)
    for layer in LAYER_ORDER:
        st.markdown(f'<div class="layer-title">{layer}</div>', unsafe_allow_html=True)
        mods = [m for m in data["modules"] if m.get("layer") == layer]
        cols = st.columns(4)
        for i, m in enumerate(mods):
            mid = m["id"]
            state = dep_state(data, payload, mid)
            with cols[i % 4]:
                desc = m.get("description","")
                desc = desc[:112] + ("..." if len(desc) > 112 else "")
                st.markdown(card_html(m["name"], desc, state, selected=st.session_state.get("selected_module")==mid, bdone=business_done(payload, mid), adone=arch_done(payload, mid)), unsafe_allow_html=True)
                label = "Add + Open" if state == "dimmed" else "Open"
                if st.button(label, key=f"btn_{mid}", use_container_width=True):
                    if state == "dimmed":
                        payload.setdefault("added_modules", [])
                        if mid not in payload["added_modules"]:
                            payload["added_modules"].append(mid)
                        ensure_records(data, payload)
                    st.session_state.selected_module = mid
                    st.rerun()

def request_context(payload):
    st.markdown('<div class="section-title">1. Request context</div>', unsafe_allow_html=True)
    st.markdown('<div class="small-muted">Keep this short. Module details go into the clicked dossier.</div>', unsafe_allow_html=True)
    ctx = payload["request_context"]
    c1,c2 = st.columns(2)
    with c1:
        ctx["name"] = st.text_input("Request / idea name", ctx.get("name",""), placeholder="e.g., Small business payment package")
        ctx["request_type"] = st.selectbox("Request type", REQUEST_TYPES, index=REQUEST_TYPES.index(ctx.get("request_type", "New product / service")) if ctx.get("request_type") in REQUEST_TYPES else 0)
    with c2:
        ctx["sponsor"] = st.text_input("LOB / sponsor", ctx.get("sponsor",""), placeholder="e.g., Small Business Banking")
        ctx["target_users"] = st.text_input("Target users", ctx.get("target_users",""), placeholder="e.g., clients, bankers, ops, contact center")
    ctx["problem"] = st.text_area("Business problem / outcome", ctx.get("problem",""), placeholder="What problem are we solving and what outcome do we need?", height=92)

def render_dossier(data, payload, role_mode):
    mid = st.session_state.get("selected_module")
    if not mid or mid not in {m["id"] for m in data["modules"]}:
        mid = next(iter(in_scope_ids(data, payload)), None)
        st.session_state.selected_module = mid
    if not mid:
        st.info("Click a module to begin.")
        return
    ensure_records(data, payload)
    m = module_by_id(data, mid)
    state = dep_state(data, payload, mid)
    d = defaults_for(data, payload, mid)
    st.markdown(f'<div class="section-title">Module dossier: {m["name"]}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="small-muted">{state.title()} dependency · {m.get("description","")}</div>', unsafe_allow_html=True)
    if mid in payload.get("added_modules", []):
        if st.button("Remove added module", key=f"remove_{mid}"):
            payload["added_modules"] = [x for x in payload.get("added_modules", []) if x != mid]
            st.session_state.selected_module = next(iter(in_scope_ids(data, payload)), None)
            st.rerun()

    if role_mode == "Business input":
        st.markdown(f'<div class="helper-box"><b>What to enter:</b> {helper_for(data, mid)}</div>', unsafe_allow_html=True)
        b = payload["business_input"][mid]
        b["need"] = st.text_area("What does this request need from this module?", b.get("need",""), height=95)
        b["today"] = st.text_area("What exists / happens today?", b.get("today",""), height=75)
        b["pain"] = st.text_area("What is painful, missing, risky, or manual?", b.get("pain",""), height=75)
        c1,c2 = st.columns(2)
        with c1:
            priorities = ["Must-have", "Should-have", "Nice-to-have", "Future phase", "Unknown", "Not applicable"]
            b["priority"] = st.selectbox("Priority", priorities, index=priorities.index(b.get("priority", "Must-have")) if b.get("priority") in priorities else 0)
        with c2:
            b["questions"] = st.text_input("Open questions", b.get("questions",""))
        st.markdown('<div class="callout"><b>Next:</b> Architecture reviews defaults and decides reuse, extension, gap, vendor/product need, integration layer, or deep dive.</div>', unsafe_allow_html=True)

    elif role_mode == "Architecture review":
        st.markdown(f"""
<div class="default-box">
<b>Default architecture starting point</b><br>
<b>Disposition:</b> {d.get("default_disposition","Unknown")}<br>
<b>Likely owners:</b> {d.get("likely_owners","Unknown")}<br>
<b>Likely risks:</b> {d.get("likely_risks","Unknown")}<br>
<b>Likely integrations:</b> {d.get("likely_integrations","Unknown")}<br>
<b>Review question:</b> {d.get("review_question","Unknown")}
</div>
""", unsafe_allow_html=True)
        if st.button("Apply default", key=f"apply_{mid}"):
            apply_default(data, payload, mid)
            st.rerun()
        a = payload["architecture_review"][mid]
        status_ops = ["Not reviewed","Default accepted","Default modified","Needs SME review","Deep dive assessment needed","Decision required"]
        avail_ops = ["Unknown","Available and reusable","Available but coupled to existing module/platform","Available but needs extension","Not available / gap","Vendor/product needed","Integration layer needed","Not applicable"]
        disp_ops = list(dict.fromkeys(["Reuse existing","Extend existing","New capability needed","Duplicate risk","Retire/replace","Unknown","Not applicable", d.get("default_disposition","Unknown")]))
        action_ops = ["Validate default with SMEs","Reuse existing module","Extend existing module","Deep dive assessment","RFP/vendor product evaluation","Add to integration layer","Create roadmap item","Defer / future phase","Not applicable"]
        c1,c2 = st.columns(2)
        with c1:
            a["status"] = st.selectbox("Review status", status_ops, index=status_ops.index(a.get("status","Not reviewed")) if a.get("status") in status_ops else 0)
        with c2:
            a["availability"] = st.selectbox("Capability availability", avail_ops, index=avail_ops.index(a.get("availability","Unknown")) if a.get("availability") in avail_ops else 0)
        c3,c4 = st.columns(2)
        with c3:
            a["disposition"] = st.selectbox("Architecture disposition", disp_ops, index=disp_ops.index(a.get("disposition", d.get("default_disposition","Unknown"))) if a.get("disposition", d.get("default_disposition","Unknown")) in disp_ops else 0)
        with c4:
            a["action"] = st.selectbox("Recommended action", action_ops, index=action_ops.index(a.get("action","Validate default with SMEs")) if a.get("action") in action_ops else 0)
        a["owner"] = st.text_input("Owner / SME", a.get("owner",""))
        a["risks"] = st.text_area("Risks / controls to validate", a.get("risks",""), height=75)
        a["integrations"] = st.text_area("Integration / platform impact", a.get("integrations",""), height=75)
        a["decision"] = st.text_area("Decision needed", a.get("decision",""), height=75)
        a["notes"] = st.text_area("Architecture notes / rationale", a.get("notes",""), height=75)
    else:
        b = payload["business_input"].get(mid, {})
        a = payload["architecture_review"].get(mid, {})
        st.markdown("##### Business input")
        st.json({"Need": b.get("need",""), "Today": b.get("today",""), "Pain": b.get("pain",""), "Priority": b.get("priority",""), "Questions": b.get("questions","")})
        st.markdown("##### Architecture review")
        st.json({"Status": a.get("status",""), "Availability": a.get("availability",""), "Disposition": a.get("disposition",""), "Action": a.get("action",""), "Owner": a.get("owner",""), "Decision": a.get("decision",""), "Notes": a.get("notes","")})

def main():
    st.set_page_config(page_title="Banking Business Architecture Intake", page_icon="🏦", layout="wide")
    css()
    init_db()
    data = load_data()
    if "payload" not in st.session_state:
        st.session_state.payload = blank_payload(data)
    if "selected_module" not in st.session_state:
        st.session_state.selected_module = next(iter(in_scope_ids(data, st.session_state.payload)), None)

    st.markdown("""
<div class="app-header">
  <div class="app-title">Banking Business Architecture Intake v8 — Streamlit</div>
  <div class="subtitle">Same visual model as the HTML: select an FNB-relevant starting point, see default modules, click a module to fill the compact dossier, save the request, and let architecture review the same view.</div>
</div>
""", unsafe_allow_html=True)

    with st.sidebar:
        st.header("Workspace")
        workspace = st.radio("Workspace", ["Create / edit request", "Architecture review queue", "Export / admin"], label_visibility="collapsed")
        role_mode = st.radio("Dossier mode", ["Business input", "Architecture review", "Summary"])
        st.caption("Local database")
        st.code(str(DB_FILE), language="text")

    if workspace == "Architecture review queue":
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Architecture review queue")
        status_filter = st.selectbox("Filter", ["All"] + STATUS_OPTIONS)
        df = list_requests(status_filter)
        st.dataframe(df, use_container_width=True, hide_index=True)
        if not df.empty:
            options = df["request_id"].tolist()
            rid = st.selectbox("Open request", options, format_func=lambda x: f"{df.loc[df['request_id']==x, 'title'].iloc[0]} · {x[:8]}")
            c1,c2 = st.columns([1,1])
            with c1:
                if st.button("Open selected request", type="primary", use_container_width=True):
                    st.session_state.payload = ensure_records(data, load_request(rid))
                    st.session_state.selected_module = next(iter(in_scope_ids(data, st.session_state.payload)), None)
                    st.rerun()
            with c2:
                if st.button("Delete selected request", use_container_width=True):
                    delete_request(rid)
                    st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)
        return

    if workspace == "Export / admin":
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Export / admin")
        df = list_requests("All")
        st.dataframe(df, use_container_width=True, hide_index=True)
        if not df.empty:
            payloads = [load_request(rid) for rid in df["request_id"]]
            st.download_button("Download all requests JSON", json.dumps(payloads, indent=2), "architecture_requests_export.json", "application/json")
            rows = []
            for p in payloads:
                rows += export_rows(data, p)
            if rows:
                st.download_button("Download all module reviews CSV", pd.DataFrame(rows).to_csv(index=False), "architecture_module_reviews.csv", "text/csv")
        st.markdown('</div>', unsafe_allow_html=True)
        return

    payload = ensure_records(data, st.session_state.payload)
    st.session_state.payload = payload

    # Top controls
    top1, top2, top3 = st.columns([2.2, .9, .9])
    with top1:
        starts = list(data["items"].keys())
        idx = starts.index(payload["selected_starting_point"]) if payload["selected_starting_point"] in starts else 0
        new_start = st.selectbox("Starting point", starts, idx)
        if new_start != payload["selected_starting_point"]:
            payload["selected_starting_point"] = new_start
            payload["selected_type"] = item(data, new_start)["type"]
            payload["added_modules"] = []
            payload["business_input"] = {}
            payload["architecture_review"] = {}
            ensure_records(data, payload)
            st.session_state.selected_module = next(iter(in_scope_ids(data, payload)), None)
            st.rerun()
    with top2:
        payload["status"] = st.selectbox("Status", STATUS_OPTIONS, index=STATUS_OPTIONS.index(payload.get("status","Draft")) if payload.get("status") in STATUS_OPTIONS else 0)
    with top3:
        if st.button("New blank request", use_container_width=True):
            st.session_state.payload = blank_payload(data)
            st.session_state.selected_module = next(iter(in_scope_ids(data, st.session_state.payload)), None)
            st.rerun()

    it = item(data, payload["selected_starting_point"])
    st.markdown(f"""
<div class="banner">
  <div>
    <div class="banner-title">{payload["selected_starting_point"]}</div>
    <div class="banner-text">{it.get("summary","")} {it.get("notes","")}</div>
  </div>
  <div class="type-tag">{it.get("type","")}</div>
</div>
""", unsafe_allow_html=True)

    render_metrics(data, payload)

    left, right = st.columns([1.55, 1], gap="large")
    with left:
        with st.container(border=True):
            request_context(payload)
        with st.container(border=True):
            st.markdown('<div class="section-title">2. Module dependency map</div>', unsafe_allow_html=True)
            st.markdown('<div class="small-muted">Click highlighted modules to fill details. Click faded modules to add them to scope.</div>', unsafe_allow_html=True)
            render_map(data, payload)
    with right:
        with st.container(border=True):
            render_dossier(data, payload, role_mode)

    st.divider()
    c1,c2,c3,c4 = st.columns(4)
    with c1:
        if st.button("Save request", type="primary", use_container_width=True):
            rid = save_payload(payload)
            st.session_state.payload = ensure_records(data, load_request(rid))
            st.success(f"Saved: {rid}")
    with c2:
        if st.button("Save + Submit", use_container_width=True):
            payload["status"] = "Submitted"
            rid = save_payload(payload)
            st.session_state.payload = ensure_records(data, load_request(rid))
            st.success(f"Submitted: {rid}")
    with c3:
        st.download_button("Download JSON", json.dumps(payload, indent=2), f"request_{payload.get('request_id') or 'draft'}.json", "application/json", use_container_width=True)
    with c4:
        st.download_button("Download CSV", pd.DataFrame(export_rows(data, payload)).to_csv(index=False), f"module_review_{payload.get('request_id') or 'draft'}.csv", "text/csv", use_container_width=True)

if __name__ == "__main__":
    main()
