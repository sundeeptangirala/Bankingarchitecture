# Banking Business Architecture Intake — Streamlit v2 HTML-style

This version is intentionally styled to look much closer to the v8 HTML artifact.

## What changed vs v1

- Same v8 FNB architecture data model.
- Same white panel / blue gradient / card-based visual language.
- Same module map style:
  - Primary
  - Supporting
  - Optional
  - User-added
  - Faded/click-to-add
- Same compact module dossier behavior.
- Persistent SQLite storage for requests.
- Architecture review queue to open saved requests.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Storage

The app creates a local SQLite file:

```text
architecture_requests.db
```

For enterprise deployment, replace SQLite with SQL Server, Snowflake, Postgres, Dataverse, SharePoint Lists, or an internal API-backed service.

## Important limitation

Streamlit native widgets cannot be pixel-perfect identical to a pure HTML/JavaScript page. This v2 uses custom CSS to mirror the HTML look as closely as possible while preserving Streamlit persistence and server-side request storage.
